// Resolution settings for E2B desktop sandbox
export const resolution = { x: 1024, y: 768 };
